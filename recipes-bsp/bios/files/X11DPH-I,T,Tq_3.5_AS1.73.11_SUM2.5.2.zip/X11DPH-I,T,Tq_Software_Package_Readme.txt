================================================================================
Supermicro System BIOS & IPMI Firmware Update Package Operation Instructions
================================================================================

Please read this document in it before performing the system BIOS or IPMI
firmware update.  Please verify that your system meets the requirments.


********************************************************************************
This update package includes the following system software updates & utilities:

--- BIOS/IPMI Firmware Update Package ---

  BIOS          - BIOS_X11DPH-0981_20210519_3.5_STD.zip  (REV 3.5)
  IPMI Firmware - SMT_X11AST2500_173_11.zip              (REV 1.73.11)

--- BIOS/Firmware Update Tools ---
 Supermicro Update Manager Utility (SUM)  v2.5.2 :
   sum_2.5.2_BSD_x86_64_20210112.tar.zip       (for Windows)
   sum_2.5.2_Linux_x86_64_20210112.tar.gz      (for Linux)
   sum_2.5.2_Win_x86_64_20210112.gz            (for FreeBSD) 
  


  Note: For BIOS/firmware update with SUM utility through Out-Of-Band (OOB)
        channel, the SFT-OOB-LIC or SFT-DCMS-Single is required for each node.

--- Supported Products ---

  Supermicro Motherboards:
  MBD-X11DPH-I,T,Tq
  


*************************************************************************************
                                     Important notes
*************************************************************************************

Downgrading BIOS below 2.0 is not supported due to a security revision change.


*************************************************************************************
                       SYSTEM HARDWARE and FIRMWARE REQUIREMENTS
*************************************************************************************

<NONE>


*************************************************************************************
                                         Warning
*************************************************************************************

1. Do not interrupt, reboot or remove power from your system during the update.
   Doing so may cause the system failure.

2. If the software update fails, you may contact our RMA Department to have the BIOS/
   IPMI firmware chip reprogrammed.  This will require shipping the board to Supermicro
   for repair.  Please submit your RMA request at:
   http://www.supermicro.com/support/rma/.
